a = [int(input()),int(input())]
b = [int(input()),int(input())]
c = [int(input()),int(input())]
x = set()
for i in range(a[0],a[1]):
    x.add(i)
for i in range(b[0],b[1]):
    x.add(i)
for i in range(c[0],c[1]):
    x.add(i)
    
answer = len(x)
print(answer)