def main():
    valid_word = set("123456789abc")
    try:
        n = int(input())
        if(n < 2 or n > 10):
            raise ValueError
    except ValueError:
        print("-1")
        exit()
    conflict,subject_name,subject_schedule,subject_schedule_classify = [],[],[],[]

    #宣告變數區
    for i in range(n):
        subject = input()
        subject_name.append(subject)
        try:
            time = int(input())
            if(time < 1 or time > 3):
                raise ValueError
        except: 
            print("-1")
            exit()
        for j in range(time):
            try:
                schedule = input()
                if(schedule[0] not in "12345" or schedule[1] not in valid_word or len(schedule) != 2):
                    raise ValueError
            except:
                print('-1')
                exit()
            subject_schedule.append(schedule)
        subject_schedule_classify.append(list(subject_schedule))
        subject_schedule.clear()
    #宣告一個字典用來存放每一節時間所對應到的課
    #判斷衝突區
    for i in range(n):
        course_i = subject_name[i]
        times_i = subject_schedule_classify[i]
        for j in range(i+1, n):  # 只比對後面的科目
            course_j = subject_name[j]
            times_j = subject_schedule_classify[j]
            # 找出兩門課的交集時間
            for t in times_i:
                if t in times_j:
                    conflict.append(f"{course_i},{course_j},{t}")
    if conflict:
        for c in conflict:
            print(c)
    else:
        print('correct')
main()
            
            
