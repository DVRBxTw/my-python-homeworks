#----------------------開心菜園----------------------#
def callAi(array:list,i:int,row:int):
    for j in range(len(array)):
        if array[row][j] != '__' and j != i:
            array[row][i] = 'Cn'
    return array
def callCn(array:list,i:int,row:int):
    if row > 0 and array[row-1][i] != '__':
        array[row][i] = 'Hy'

    return array
def callHy(array:list,i:int,row:int):
    record = 0
    if row != 0 and array[row-1][i] != '__':
        record += 1
    if i != 0 and array[row][i-1] != '__':
        record += 1
    if i != 4 and array[row][i+1] != '__':
        record += 1
    if row != 4 and array[row+1][i] != '__':
        record += 1
    if array[row][i] == 'Hy':
        if record >= 2:
            if row != 0 and array[row-1][i] == '__':
                array[row-1][i] = 'Na'
            if i != 0 and array[row][i-1] == '__':
                array[row][i-1] = 'Na'
            if i != 4 and array[row][i+1] == '__':
                array[row][i+1] = 'Na'
            if row != 4 and array[row+1][i] == '__':
                array[row+1][i] = 'Na'
    return array
def callNa(array:list,i:int,row:int):
    if i > 0  :
        array[row][i-1] = 'Hy'
    if i != 4 and array[row][i+1] == '__':
        array[row][i+1] = 'Qx'
    return array
def callQx(array:list,i:int,row:int):
    count_array = []
    for index in array[row]:
        count_array.append(index)
    if count_array.count('Cn') >= 3:
        for j in range(len(array)):
            if array[row][j] == 'Cn':
                array[row][j] = 'Ai'
    if count_array.count('Hy') >= 3:
        for j in range(len(array)):
            if array[row][j] == 'Hy':
                array[row][j] = 'Ai'
    if count_array.count('Na') >= 3:
        for j in range(len(array)):
            if array[row][j] == 'Na':
                array[row][j] = 'Ai'
    if count_array.count('Qx') >= 3:
        for j in range(len(array)):
            if array[row][j] == 'Qx':
                array[row][j] = 'Ai'
    return array 
def main():                 
    days = int(input())
    array = []
    for i in range(5):
        inp = input().split()
        array.append(inp)
#-----------------索引陣列資料---------------------#
    for day in range(days):
        row,c = 0,0
        execute_array,i_array,row_array = [],[],[]
        for index in array:
            for i in range(len(array)):
                if index[i] == 'Ai':
                    execute_array.append('Ai')
                    i_array.append(i)
                    row_array.append(row)
                elif index[i] == 'Cn':
                    execute_array.append('Cn')
                    i_array.append(i)
                    row_array.append(row)
                elif index[i] == 'Hy':
                    execute_array.append('Hy')
                    i_array.append(i)
                    row_array.append(row)
                elif index[i] == 'Na':
                    execute_array.append('Na')
                    i_array.append(i)
                    row_array.append(row)
                elif index[i] == 'Qx':
                    execute_array.append('Qx')
                    i_array.append(i)
                    row_array.append(row)
            row += 1
        for index in execute_array:
            if index == 'Ai':
                array = callAi(array,i_array[c],row_array[c])
            elif index == 'Cn':
                array = callCn(array,i_array[c],row_array[c])
            elif index == 'Hy':
                array = callHy(array,i_array[c],row_array[c])
            elif index == 'Na':
                array = callNa(array,i_array[c],row_array[c])
            elif index == 'Qx':
                array = callQx(array,i_array[c],row_array[c])
            c += 1
#------------------輸出---------------------------#
    for output in array:
        print(*output)
main()
