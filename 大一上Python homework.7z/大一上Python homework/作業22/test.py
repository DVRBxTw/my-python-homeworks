def R(m,n):
    forwardrotate,new_matrix = list(),list()
    for i in range(n):
        forwardrotate = []
        for j in reversed(m):
            forwardrotate.append(j[i])
        new_matrix.append(forwardrotate)
    return new_matrix
def L(m,n):
    reversedrotate,new_matrix = list(),list()
    for i in range(n):
        reversedrotate = []
        for j in m:
            reversedrotate.append(j[-1-i])
        new_matrix.append(reversedrotate)
    return new_matrix
def main():
    n = int(input())
    num = list(range(1,n**2 + 1))
    matrix = list(num[i:i+n] for i in range(0,len(num),n))
    commands = input()
    for i in commands:
        if(i == 'R'):
            matrix = R(matrix,n)
        elif(i == 'L'):
            matrix = L(matrix,n)
    for index in matrix:
        print(*index)
main()
