#-------------------------梭哈牌型-------------------------#
def rule5(cards_first:list,numbers:list,score:int):
    c = -1
    array,temp_array = [],[]
    for i in range(len(numbers)):
        temp_array = []
        c += 1
        for j in range(5):
            if c <= 9:
                temp_array.append(numbers[j+c])
                if c == 9:
                    c = -4
            else:
                temp_array.append(numbers[j+c])
        array.append(temp_array)
    count = 0
    cards_first.sort()
    for i in range(len(array)):
        if sum(cards_first) == sum(array[9+count]):
            cards_first = [10+count,11+count,12+count,13+count,14+count]
            for j in range(len(cards_first)):
                if cards_first[j] > 13:
                    cards_first[j] = cards_first[j] % 13
        if(i >= 9):
            count += 1
    if cards_first in array and score < 5:
        return 5
    else:
        return score
    
def rule1to4(cards,cards_first,score:int):
    count = 0
    for i in range(len(cards)):
        for j in range(i,len(cards)):
            if(j < len(cards) - 1):
                if cards_first[i] == cards_first[j+1]:
                    count += 1
    if count == 3 and score < 3:
        return 4
    elif count == 2 and score < 2:
        return 3
    elif count == 1 and score < 1:
        return 2 
    elif count == 0 and score <= 0:
        return 1
    else:
        return score
def rule6(cards_colors:list,score:int):
    if((cards_colors.count('S') == 5 or cards_colors.count('H') == 5 or cards_colors.count('D') == 5 or cards_colors.count('C') == 5) and score < 6):
        return 6
    else:
        return score
def rule7(cards_first,score):
    count = 0
    for i in range(len(cards_first)):
        for j in range(i,len(cards_first)):
            if(j < len(cards_first) - 1):
                if cards_first[i] == cards_first[j+1]:
                    count += 1
    if count == 4 and score < 7:
        return 7
    else:
        return score
def rule8(cards_first,score):
    count = 0
    for i in range(len(cards_first)):
        for j in range(i,len(cards_first)):
            if(j < len(cards_first) - 1):
                if cards_first[i] == cards_first[j+1]:
                    count += 1
    if count == 6 and score < 8:
        return 8
    else:
        return score
def rule9(cards_first:list,numbers:list,score:int,cards_colors:list):
    c = -1
    array,temp_array = [],[]
    for i in range(len(numbers)):
        temp_array = []
        c += 1
        for j in range(5):
            if c <= 9:
                temp_array.append(numbers[j+c])
                if c == 9:
                    c = -4
            else:
                temp_array.append(numbers[j+c])
        array.append(temp_array)
    count = 0
    cards_first.sort()
    for i in range(len(array)):
        if sum(cards_first) == sum(array[9+count]):
            cards_first = [10+count,11+count,12+count,13+count,14+count]
            for j in range(len(cards_first)):
                if cards_first[j] > 13:
                    cards_first[j] = cards_first[j] % 13
        if(i >= 9):
            count += 1
    if cards_first in array and (cards_colors.count('S') == 5 or cards_colors.count('H') == 5 or cards_colors.count('D') == 5 or cards_colors.count('C') == 5) and score < 9 :
        return 9
    else:
        return score
def main():
#-------------------------宣告及檢查變數區--------------------#
    score = 0
    colors = ['S','H','D','C']
    numbers = ['A','2','3','4','5','6','7','8','9','10','J','Q','K']
    cards = input().split()
    for check in range(5):
        if(len(cards[check]) == 2):
            if cards[check][0] not in numbers or cards[check][1] not in colors or len(cards[check]) > 2:
                print('Error input')
                exit()
        elif(len(cards[check]) == 3) and cards[check][0:2] != '10':
            print('Error input')
            exit()
    if len(cards) != len(set(cards)):
        print('Duplicate deal')
        exit()
#--------------------------捕捉花色前的字元-----------------------#
    cards_first = []
    for i in range(len(cards)):
        if(len(cards[i]) == 3):
            cards_first.append(cards[i][0:2])
        else:
            cards_first.append(cards[i][0])
#--------------------------捕捉花色字元---------------------------#
    cards_colors = []
    for i in range(len(cards)):
        if(len(cards[i]) == 3):
            cards_colors.append(cards[i][2])
        else:
            cards_colors.append(cards[i][1])
#-------------------------將AJQK轉換成1 11 12 13--------------#
    for i in range(len(numbers)):
        if numbers[i] == 'A':
            numbers[i] = 1
        if numbers[i] == 'J':
            numbers[i] = 11
        if numbers[i] == 'Q':
            numbers[i] = 12
        if numbers[i] == 'K':
            numbers[i] = 13
        else:
            numbers[i] = int(numbers[i])
    for i in range(len(cards_first)):
        if cards_first[i] == 'A':
            cards_first[i] = 1
        if cards_first[i] == 'J':
            cards_first[i] = 11
        if cards_first[i] == 'Q':
            cards_first[i] = 12
        if cards_first[i] == 'K':
            cards_first[i] = 13
        else:
            cards_first[i] = int(cards_first[i])
#--------------------------判斷規則---------------------------------#
    score = rule9(cards_first,numbers,score,cards_colors)
    score = rule8(cards_first,score)
    score = rule7(cards_first,score)
    score = rule6(cards_colors,score)
    score = rule5(cards_first,numbers,score)
    score = rule1to4(cards,cards_first,score)
    print(score)    
main()  