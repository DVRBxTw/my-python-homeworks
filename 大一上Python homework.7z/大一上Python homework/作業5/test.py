def BMI(h,w):
    BMI = w / h**2
    if (BMI >= 35):
        return 'Severe obesity'
    elif (BMI < 35 and BMI >= 30):
        return 'Moderate obesity'
    elif (BMI < 30 and BMI >= 27):
        return 'Mild obesity'
    elif (BMI < 27 and BMI >= 24):
        return 'Overweight'
    elif (BMI < 24 and BMI >= 18):
        return 'Normal'
    else:
        return 'Underweight'
h = float(input())
w = int(input())
print(BMI(h,w))