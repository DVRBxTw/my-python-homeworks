def main():
    scores = []
    special_words = " ~!@#$%^&*<>_+="
    sub_str = '1234'
    password = []
    password_dict = {}
    n = int(input())
    for i in range(n):
        p = input()
        password.append(p)
    for t in password:
        score,count = 0.0,0.0
        for paswd in t:
            if paswd.islower(): #規則1
                score += 1.0
            if paswd.isupper(): #規則2
                score += 3.0
            if paswd.isdigit(): #規則3
                score += 2.0
            if paswd in special_words: #規則4
                score += 4.5

            #規則5
        sequence_digit = False
        for i in range(len(t)): #i計數器 範圍在t的密碼長度中
            if t[i].isdigit(): #如果t的第i個位元是數字
                count += 1 #那麼count + 1
                if(i+1 < len(t) and t[i+1].isdigit()): #如果當前位置的下一個位元也是數字
                    sequence_digit = True #讓連續 = True

        if count >= 5 and not sequence_digit:
            score += 10

        if len(t) > 8: #規則6
            score += len(t) - 8
        if sub_str in t: #規則7
            score -= 10            
        password_dict[t] = score
        max_Name = max(password_dict, key=password_dict.get)
        maxValue = max(password_dict.values())
        min_Name = min(password_dict, key=password_dict.get)
        minValue = min(password_dict.values())
    print(f"{max_Name} {maxValue}")
    print(f"{min_Name} {minValue}")
main()