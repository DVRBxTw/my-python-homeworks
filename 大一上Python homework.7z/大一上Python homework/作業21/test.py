def main():
    mode = int(input())
    try:
        n = int(input())
        if(n < 3 or n > 50):
            raise ValueError
    except ValueError:
        print('Row Error')
        exit()
    if(mode == 1):
        char1 = ""
        for i in range(n):
            char1 += str(i+1) 
            if (i == 0):
                char2 = ''
            else:
                char2 += str(i)
            char2_reversed = ''.join(reversed(char2)) #讓char2被相反
            print(char1+char2_reversed)
    elif(mode == 2):
        main_char = ''
        char2 = ''
        _ = "_"
        for i in range(n):
            char2 += str(i+1)
            if(i == 0):
                char1 = ''
            else:
                char1 += str(i)
            char1_reversed = ''.join(reversed(char1))
            main_char = _*(n-i-1) + char2 + char1_reversed + _*(n-i-1) #每行前後輸出(n-1)個_
            print(main_char)

    elif(mode == 3):
        main_char,char,char1,char2,char_list = '','','','',[]
        _ = "_"
        for i in range(n): #假設n=4 
            char1 += str(i+1) #char1最後變成'1234'
            if(i == 0):
                char2 = '' #如果現在是第0次 那麼char2是空白
            else:
                char2 += str(i) #如果超過第0次 那麼char2就是i慢慢加上去 最後變成123
            char2_reversed = ''.join(reversed(char2)) #把char2相反過來最後變321
            char = char1 + char2_reversed #char暫存 char1+char2的數值
            char_list.append(char) #把char的資料 存在char_list陣列裡面 分別是['1','121',12321','1234321']
        for i in range(n):
            main_char = _*i + char_list[n-i-1] + _*i
            print(main_char)
main()