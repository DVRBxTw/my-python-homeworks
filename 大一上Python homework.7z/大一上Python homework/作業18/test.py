M = int(input()) #1<=M<=2 1為Player先下棋 2為Computer先下棋
chess = input().split() #1 4 2 8 3 #假設M=1 那麼1 2 3為Player所下的棋子 4 8 為Computer所下的棋子
chess = list(map(int, chess)) #將所輸入的chess轉換成int型態的陣列
result = "0 0 0 0 0 0 0 0 0".split() #將result轉換成list型態來暫存每一次運算的結果
ans = ''
pwin,cwin = False,False
win = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]] #列出所有勝利條件
while(M == 1): 
    for i in range(len(chess)): #i是索引值
        val = chess[i] #把每一次棋子的位置暫存在val變數裡
        if(i % 2 == 0): #如果是奇數輸入 
            result[val-1] = '1' #把val-1的那一格替換成玩家的棋子
        elif(i % 2 == 1): #如果是偶數輸入
            result[val-1] = '2' #把val-1的那一格替換成電腦的棋子
    break
while(M == 2):
    for i in range(len(chess)):
        val = chess[i]
        if(i % 2 == 0):
            result[val-1] = '2'
        elif(i % 2 == 1):
            result[val-1] = '1'
    break
for i in range(9): #讓i跑9次 i=0 到 8
    if(i % 3 == 0 and i != 0): #當i跑到3的倍數時 每三個元素換一次行
        ans += '\n'
    ans += ''.join(result[i]) #把每一個棋子輸出成3x3的樣式
    ans += ' '
for a,b,c in win: #將a,b,c引入win獲勝條件陣列
    if result[a] == result[b] == result[c] != '0':
        if result[a] == '1':
            pwin = True
        else:
            cwin = True 
print(ans)
if(cwin):
    print('Computer win')
elif(pwin):
    print('Player win')
else:
    print('Undecided')