#練習.format函式輸出字串
import math
name = input()
id =int(input())
chinese = int(input())
count = int(input())
program = int(input())
total = chinese + count + program
average = total//3
str='Name:{0}\nId:{1}\nTotal:{2}\nAverage:{3}\n'.format(name,id,total,average)
print(str)