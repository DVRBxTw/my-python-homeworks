balls,bonus_score = [],0
round1,round2,round3 =  0,0,0
strike,spare,bonus= False,False,False
for i in range(2): #第一局
    a = int(input())
    balls.append(a)
    if(balls[i] == 10): #如果strike 第一局分數+10分並且結束第一局的迴圈
        round1 += 10
        strike = True 
        break
    else:               #如果沒有strike 第一局分數為兩顆球總共擊落多少瓶杯子數
        round1 += balls[i]
        strike = False
if (len(balls) == 2): #判斷是否有執行兩回合 
    if((balls[0]+balls[1]) == 10 and strike == False): #如果兩顆球加起來是10的倍數 且 不是strike那麼就是spare第一round分數算到下一球
        spare = True
    else:
        spare = False
else:
    spare = False
temp = strike #令strike的boolean代入temp
strike = False
balls.clear() #清空第一局的球
for i in range(2): #第二局
    a = int(input())
    balls.append(a)
    if(temp):
        if(balls[i] == 10): #如果第二局第一球strike 那麼獲得第二局獲得10分且要加後面兩球
            round1 += balls[i]
            strike = True
            break
        else:
            round1 += balls[i] #如果第二局第一球沒有strike那麼第一局的分數就加上這球的擊倒瓶數
            strike = False
    elif(spare): #如果第一局spare
        round1 += balls[i] #那麼第一局的分數就加上第二局第一球的分數
        spare = False
    if(balls[i] == 10): #如果第一局沒有strike但第二局第一球strike
        round2 += balls[i] #那麼第二局的分數加10分
        strike = True
        break
    else:
        round2 += balls[i] #如果沒有strike那第二局的分數就是該球的擊倒瓶數
        strike = False

if(len(balls) == 2 ): #判斷是否有執行兩回合 
    if((balls[0] + balls[1]) == 10 and strike == False): #如果兩顆球加起來是10的倍數 且 不是strike那麼就是spare第一round分數算到下一球
        spare = True
    else:
        spare = False
else:
    spare = False
temp = strike
strike = False
balls.clear() #重置球瓶
for i in range(2): #第三局
    a = int(input())
    balls.append(a)
    if(temp and round1 % 10 == 0):
        round1 += 10
    if(temp):#如果第二局strike
        if(balls[i] == 10): #如果第二局strike且如果第三局的第一顆球也strike
            round2 += balls[i] #那麼第二局的分數加10分
            strike = True
            bonus = True
            break
        else:
            round2 += balls[i]
            strike = False
    elif(spare):
        round2 += balls[i]
        spare = False
    if(balls[i] == 10):
        round3 += balls[i]
        strike = True
        bonus = True
        break
    else:
        round3 += balls[i]
        strike = False
if(len(balls) == 2 ):
    if((balls[0] + balls[1]) == 10 and strike == False):
        spare = True
        bonus = True
    else:
        spare = False
else:
    spare = False
balls.clear()
if(bonus and strike):
    for i in range(2):
        a = int(input())
        balls.append(a)
        bonus_score += balls[i]
elif(bonus and spare):
    a = int(input())
    balls.append(a)
    bonus_score += balls[0]
if(temp and round3 % 10 == 0):
    round3 += balls[0]
total = round1 + round2 + round3 + bonus_score
if(round1 % 10 == 0 and round2 % 10 == 0 and round3 % 10 == 0): #判斷是否全局都strike
    total += 20
print(total)