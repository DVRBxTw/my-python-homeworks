#------------------------------金魚與數字金字塔---------------------------------#
def fish(n:int,m:int):
    ch1,ch2 = '_','*'
    mid = n*3-1
    if m % 2 == 1:
        for i in range(n-1):
            print(ch1*(n-1-i) + ch2*(2*i+1) + ch1*2*(n-1-i) + ch2*(i+1))
        print(ch2*(mid))
        for i in range(n-1,0,-1):
            print(ch1*(n-i) + ch2*(2*i-1) + ch1*2*(n-i) + ch2*(i))
    elif m % 2 == 0:
        for i in range(n-1):
            print(ch2*(i+1) + ch1*(2*(n-1)-(2*i)) + ch2*(2*i+1) + ch1*(n-1-i))
        print(ch2*(mid))
        for i in range(n-1,0,-1):
            print(ch2*(i) + ch1*(2*(n-i)) + ch2*(2*i-1) + ch1*(n-i))
def pyramid(n,m):
    ch,char = '_',''
    output_array,math_array = [['1']],['1']
#-----------------將數字金字塔分成陣列式後代入每一個print----------------#
    for i in range(n):
        if i > 0:
            math_array.insert(0,str(i+1))
            math_array.insert(i*2,str(i+1))
            output_array.append([*math_array])
    if m % 2 == 1:
        for i in range(n):
            print(ch*(n-1-i),end='')
            print(*output_array[i],sep='',end='')
            print(ch*(n-1-i))
    elif m % 2 == 0:
        for i in range(n-1,-1,-1):
            print(ch*(n-i-1),end = '')
            print(*output_array[i],sep='',end='')
            print(ch*(n-i-1))
def main():
    n = int(input())
    m = int(input())
    c = int(input())
    if c == 1:
        fish(n,m)
    elif c == 2:
        pyramid(n,m)
main()
