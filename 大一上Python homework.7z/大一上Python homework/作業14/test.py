def mv(x: float, y: float): #執行mv指令
    position[0] += float(x)
    position[1] += float(y)
def rotate(angle:float,temp:float):
    temp += angle
    temp %= 360
    return temp
def set_pattern(pattern: str):
    return pattern
def set_color(color: str):
    return color
def stamp(p,r,pattern,color):
    s = f'Stamping... [position: ({p[0]:.2f}, {p[1]:.2f}), rotation: {r:.2f} degrees, pattern: {pattern}, color: {color}]'
    output.append(s)
    return output
output = []
position = [0.0,0.0]
angle = 0.0
rotation = 0.0
pattern = 'no_pattern'
color = 'black'
stamped = bool
for _ in range(6):
    a = input()
    catch = a.split()
    command = catch[0]
    a = None
    if (command == 'mv'):
        mv(float(catch[1]),float(catch[2]))
    elif(command == 'rotate'):
        rotation = rotate(float(catch[1]),float(rotation))
    elif(command == 'set_pattern'):
        pattern = set_pattern(catch[1])
    elif(command == 'set_color'):
        color = set_color(catch[1])
    elif(command == 'stamp'):   
        stamped = True
        output_request = stamp(position,rotation,pattern,color)
    elif(command == 'reset'):
        position = [0.0,0.0]
        angle = 0.0
        rotation = 0.0
        pattern = 'no_pattern'
        color = 'black'
    catch = None
    command = None
if _+1==6 and stamped== True:
    print('\n'.join(output_request))  
else:
    print('Stamping canceled')
    

        
                
