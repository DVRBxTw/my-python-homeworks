def tidy(p: list):
    to_remove = set()
    for i in range(len(p)):
        for j in range(i + 1, len(p)):
            if p[i][1] == p[j][1]:
                to_remove.add(p[i])
                to_remove.add(p[j])
    new_p = [x for x in p if x not in to_remove]
    return new_p
def guess(p1:list,p2:list,guess):
    stop = False
    if guess in p2:
        p1.append(guess)
        p2.remove(guess)
    else:
        stop = True
    return stop

def main():
    Player1_cards = input().split()
    Player2_cards = input().split()
    Bot_cards = input().split()

    Player1_cards = tidy(Player1_cards)
    Player2_cards = tidy(Player2_cards)
    Bot_cards = tidy(Bot_cards)

    Player1_guess = input()
    Player2_guess = input()
    Bot_guess = input()
    stop1 = guess(Player1_cards,Player2_cards,Player1_guess)
    Player1_cards = tidy(Player1_cards)
    Player2_cards = tidy(Player2_cards)
    Bot_cards = tidy(Bot_cards)
    stop2 = guess(Player2_cards,Bot_cards,Player2_guess)
    Player1_cards = tidy(Player1_cards)
    Player2_cards = tidy(Player2_cards)
    Bot_cards = tidy(Bot_cards)
    stop3 = guess(Bot_cards,Player1_cards,Bot_guess)
    Player1_cards = tidy(Player1_cards)
    Player2_cards = tidy(Player2_cards)
    Bot_cards = tidy(Bot_cards)
    if stop1 == True or stop2 == True or stop3 == True:
        print('Error')
        exit()
    else:
        print(*Player1_cards)
        print(*Player2_cards)
        print(*Bot_cards)

main()
