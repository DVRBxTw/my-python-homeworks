import math
inside = int(input())
outside = int(input())
call = int(input())
inside_message = int(input())
outside_message = int(input())
plan_183 = (0.08,0.1393,0.1349,1.1287,1.4803,183)
plan_383 = (0.07,0.1304,0.1217,1.1127,1.2458,383)
plan_983 = (0.06,0.1087,0.1018,0.9572,1.1243,983)
def judge(x,plan):
    if (x < plan):
        return plan
    else:
        return x
def count_price(A,B,C):
    result_A = int((A[0]*inside + A[1]*outside + A[2]*call + A[3]*inside_message + A[4]*outside_message))
    result_B = int((B[0]*inside + B[1]*outside + B[2]*call + B[3]*inside_message + B[4]*outside_message))
    result_C = int((C[0]*inside + C[1]*outside + C[2]*call + C[3]*inside_message + C[4]*outside_message))
    #計算出價格是否低於該方案的月租價
    a=judge(result_A,plan_183[5])
    b=judge(result_B,plan_383[5])
    c=judge(result_C,plan_983[5])
    best_plan = (a,b,c)
    #排序價格由低到高
    best_plan_sort = sorted(best_plan)
    #判斷哪個方案最優惠
    print(best_plan_sort[0])
    if(best_plan_sort[0] >= plan_183[5] and best_plan_sort[0] < plan_383[5]):
        print('183')
    elif(best_plan_sort[0] >= plan_383[5] and best_plan_sort[0] < plan_983[5]):
        print('383')
    else:
        print('983')
#呼叫count_price函式
count_price(plan_183,plan_383,plan_983)


