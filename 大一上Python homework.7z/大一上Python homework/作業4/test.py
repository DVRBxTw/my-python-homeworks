#計算價格
x = abs(int(input()))
y = abs(int(input()))
z = abs(int(input()))
A_Price = 440
B_Price = 1200
C_Price = 130
total = x*A_Price + y*B_Price + z*C_Price
print(total)