def convert(cards:list):
    score = 0
    special = ['J','Q','K']
    for i in cards:
        if i in special:
            score += 0.5
        elif i == 'A':
            score += 1
        else:
            score += int(i)
    return score
def compare(chips,computer_score,Players_scores):
    count = 0
    computer_total = 0
    for index,ch in zip(Players_scores,chips):
        count += 1
        if (index[0] > computer_score and index[0] <= 10.5) or computer_score > 10.5 or index[0] == 10.5:
            print(f'Player{count} +{ch}')
            computer_total -= ch
        elif index[0] == computer_score:
            print(f'Player{count} -{ch}')
            computer_total += ch
        else:
            print(f'Player{count} -{ch}')
            computer_total += ch
    if(computer_total >= 0):
        print(f'Computer +{computer_total}')
    else:
        print(f'Computer {computer_total}')
def main():
    count = 0
    computer_cards,Players_cards,computer_score,Players_scores = [],[],[],[]
    n = int(input())
    chips = list(map(int, input().split()))
    first_cards = input().split()
    computer_cards.append(first_cards.pop(0))

    computer_score = convert(computer_cards)
    for index in first_cards:
        Players_cards.append([index])

    for i in range(len(Players_cards)):
        Players_scores.append([convert([Players_cards[i][0]])])
    computer_cards.clear()
    Players_cards.clear()

    for i in range(len(Players_scores)):
        while(1):
            request = input().split()
            if request[0] == 'Y': 
                Players_scores[i][0] += convert([request[1]])
                if(Players_scores[i][0] >= 10.5):
                    count += 1
                    break
            elif request[0] == 'N':
                break
    minimum = min(Players_scores)
    a = minimum[0]
    maximum = max(Players_scores)
    b = maximum[0]
    if count != len(Players_scores) and a >= computer_score:
        while(1):
            request = input()
            if(request != 'N'):
                computer_score += convert([request])
                if computer_score >= 10.5 or a < computer_score:
                    break
            elif(request == 'N'):
                break
    compare(chips,computer_score,Players_scores)
main()