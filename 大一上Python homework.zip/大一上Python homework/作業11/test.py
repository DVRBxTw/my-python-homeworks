courses = []      # 存課程編號
schedules = []    # 存所有課程的時間
conflicts = []    # 存衝突的紀錄 (課程1, 課程2, 衝突時間)

# 輸入三門課 (每門課兩個時間)
for i in range(3):
    course = int(input())            # 輸入課程編號
    courses.append(course)
    t1 = int(input())                # 第一個時間
    t2 = int(input())                # 第二個時間
    schedules.append(t1)
    schedules.append(t2)

def isconflict(courses):
    for i in range(3):
        check_state = courses[i]
        for j in range(2):
            if (i == 0):
                if(schedules[j] == schedules[2]):
                    conflicts.append((courses[i],courses[1],schedules[j]))
                if(schedules[j] == schedules[3]):
                    conflicts.append((courses[i],courses[1],schedules[j]))
                if(schedules[j] == schedules[4]):
                    conflicts.append((courses[i],courses[2],schedules[j]))
                if(schedules[j] == schedules[5]):
                    conflicts.append((courses[i],courses[2],schedules[j]))
            elif (i == 1):
                if(schedules[j+2] == schedules[0]):
                    conflicts.append((courses[i],courses[0],schedules[j+2]))
                if(schedules[j+2] == schedules[1]):
                    conflicts.append((courses[i],courses[0],schedules[j+2]))
                if(schedules[j+2] == schedules[4]):
                    conflicts.append((courses[i],courses[2],schedules[j+2]))
                if(schedules[j+2] == schedules[5]):
                    conflicts.append((courses[i],courses[2],schedules[j+2]))
            else:
                if(schedules[j+4] == schedules[0]):
                    conflicts.append((courses[i],courses[0],schedules[j+4]))
                if(schedules[j+4] == schedules[1]):
                    conflicts.append((courses[i],courses[0],schedules[j+4]))
                if(schedules[j+4] == schedules[2]):
                    conflicts.append((courses[i],courses[1],schedules[j+4]))
                if(schedules[j+4] == schedules[3]):
                    conflicts.append((courses[i],courses[1],schedules[j+4]))
    conflicts.sort()
    if not conflicts: #在Python裡如果list裡面沒有資料 那麼將會被視為false
        print('correct')
    else:
        answer = repeat(conflicts) # return result回來的數據會存在answer裡
        for a,b,t in answer:
            print(f"{a} and {b} conflict on {t}")

def repeat(conflicts):
    cleaned = set() #宣告一個集合 用來存放已經出現過的數據
    record = () #暫存內容
    result = [] #存最後處理的結果
    for a,b,t in conflicts: #如果conflicts有三筆資料分別為[(101,102,3),(102,101,3),(101,103,2)]那麼第一次a = 101 b = 102 c = 3 第二次a = 102 b = 101 c = 3
        if(a > b): #如果a>b那麼交換a跟b的位子 因為題目要求小的要在前面 例如 1001 and 1002 conflict on 25
            a,b = b,a
        record = (a, b, t) #紀錄這時候的結果
        if record not in cleaned: #如果record的內容沒有出現在cleaned集合內過
            cleaned.add(record) #那麼就把record的內容存在cleaned集合裡面
            result.append(record) #將record的內容加入到result裡
    result.sort() #將result由小到大排列
    return result 
isconflict(courses)