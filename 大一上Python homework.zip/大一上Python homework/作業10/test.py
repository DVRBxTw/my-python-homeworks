import math
#宣告以下變數 A,B,C三種書本 以及各個折扣
A, A1, A2, A3 = ((input().split()))
B, B1, B2, B3 = ((input().split()))
C, C1, C2, C3 = ((input().split()))
x = [int(A1), int(A2), int(A3), 1, 380, int(A)] 
y = [int(B1), int(B2), int(B3), 1, 1200, int(B)]
z = [int(C1), int(C2), int(C3), 1, 180, int(C)]
compare = [x, y, z]
#把輸入的折扣除以100
for i in range(3):
    x[i] = int(x[i]) / 100
    y[i] = int(y[i]) / 100
    z[i] = int(z[i]) / 100
#計算以下折扣
def calc(compare):
    rank = [1,2,3]
    answer = int()
    #compare陣列存取x,y,z三個陣列，也就是二維陣列
    for i in range(3):
        if(compare[i][5] >= 31):
            total = math.ceil(compare[i][4] * compare[i][5] * compare[i][2])
        elif(compare[i][5] >= 21 and compare[i][5] < 31):
            total = math.ceil(compare[i][4] * compare[i][5] * compare[i][1])
        elif(compare[i][5] >= 11 and compare[i][5] < 21):
            total = math.ceil(compare[i][4] * compare[i][5] * compare[i][0])
        else:
            total = math.ceil(compare[i][4] * compare[i][5] * compare[i][3])
        rank[i] = total #把所有數據分別存到rank陣列裡面
        answer += total #將total全部加總起來
    A = rank[0]
    B = rank[1]
    C = rank[2]
    #判斷A,B,C的花費哪個較多
    if (A > B and A > C):
        print("A: " + str(rank[0]))
    elif(B > A and B > C):
        print("B: " + str(rank[1]))
    else:
        print("C: " + str(rank[2]))

    if(A < B and A < C):
        print("A: " + str(rank[0]))
    elif(B < A and B < C):
        print("B: " + str(rank[1]))
    else:
        print("C: " + str(rank[2]))
    print(answer)
calc(compare)