#計算一元二次方的兩相異實根或虛根
import math

a = int(input())
b = int(input())
c = int(input())


if(b*b-4*a*c < 0):
    r = (-b)/(2*a)
    x1 = abs(math.sqrt(-(b*b-4*a*c))/(2*a))
    x2 = abs(math.sqrt(-(b*b-4*a*c))/(2*a))
    print('%.1f+%.1fi' %(r,x1))
    print('%.1f-%.1fi' %(r,x2))

if(b*b-4*a*c >= 0):
    r1 = ((-b)+math.sqrt((b*b-4*a*c)))/(2*a)
    r2 = ((-b)-math.sqrt((b*b-4*a*c)))/(2*a)
    if(r1==r2):
        print('%.1f' %r2)
    elif(b*b-4*a*c > 0):
        print('%.1f' %r1)
        print('%.1f' %r2)





