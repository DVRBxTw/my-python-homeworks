x1 = input()
x2 = input()
x3 = input()
y1 = input()
y2 = input()
y3 = input()
#把A J Q K轉換成數字跟字串型態轉成整數型態
def convert(x1,x2,x3,y1,y2,y3):
    cards = [x1,x2,x3,y1,y2,y3]
    for i in range(6):
        if(cards[i] == 'A'):
            cards[i] = 1
        elif(cards[i] == 'J' or cards[i] == 'Q' or cards[i] == 'K'):
            cards[i] = 0.5
        else:
            cards[i] = int(cards[i])
    return cards
#判斷小數點是否為.0如果是的話 把他轉乘int型態 如果不是的話列印出原本的值
def point(x,y):
    if(x == int(x)):
        print(int(x))
    else:
        print(x)
    if(y == int(y)):
        print(int(y))
    else:
        print(y)
#計算總點數並且判斷是否大於10點半
def calc(scores):
    x_point = 0
    y_point = 0
    for i in range(3):
        x_point += scores[i]
        y_point += scores[i+3]
    if(x_point > 10.5):
        x_point = 0
    if(y_point > 10.5):
        y_point = 0
    point(x_point,y_point)
    if(x_point > y_point):
        print('X Win')
    elif(x_point < y_point):
        print('Y Win')
    else:
        print("Tie")
points = convert(x1,x2,x3,y1,y2,y3)
calc(points)