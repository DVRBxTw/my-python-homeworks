import math

A = abs(int(input()))
B = abs(int(input()))
C = abs(int(input()))
A_price = 380
B_price = 1200
C_price = 180
A_discounts = (0.8,0.85,0.9,1)
B_discounts = (0.8,0.85,0.95,1)
C_discounts = (0.7,0.8,0.85,1)
def price(x,y,price):
    if(x>30):
        return x*y[0]*price
    elif(x<=30 and x>20):
        return x*y[1]*price
    elif(x<=20 and x>10):
        return x*y[2]*price
    else:
        return x*y[3]*price

A_total = int(math.ceil(price(A,A_discounts,A_price)))
B_total = int(math.ceil(price(B,B_discounts,B_price)))
C_total = int(math.ceil(price(C,C_discounts,C_price)))
total = A_total + B_total + C_total
print((int(math.ceil((total)))))
