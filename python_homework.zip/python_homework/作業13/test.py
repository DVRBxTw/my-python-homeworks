year = []
def compare(year):
    if(year % 4 == 0):
        if(year % 100 != 0 or year % 400 == 0):
            print('Leap Year')
        else:
            print('Common Year')
    else:
        print('Common Year')
for i in range(2):
    a = int(input())
    year.append(a)
for j in year:
    compare(j)
    

