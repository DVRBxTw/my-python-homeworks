a = int(input())
b = int(input())
c = int(input())
nums = (a,b,c)
nums_s = sorted(nums) #由小到大排列邊長
def triangle():
        if(a+b>c and a+c>b and b+c>a and a>0 and b>0 and c>0):
                max = nums_s[2]
                mid = nums_s[1]
                mini = nums_s[0]
                if(a==b==c):
                        print('Equilateral Triangle')
                        if(a == b or a == c or b == c ):
                                print('Isosceles Triangle')
                                if(max**2 > mid**2 + mini**2):
                                        print('Obtuse Triangle')
                                elif(max**2 < mid**2 + mini**2):
                                        print('Acute Triangle')
                                else:
                                        print('Right Triangle')
                elif(a == b or a == c or b == c):
                        print('Isosceles Triangle')
                        if(max**2 > mid**2 + mini**2):
                                print('Obtuse Triangle')
                        elif(max**2 < mid**2 + mini**2):
                                print('Acute Triangle')
                        elif(max**2 == mid**2 + mini**2):
                                print('Right Triangle')
                elif(max**2 > mid**2 + mini**2):
                        print('Obtuse Triangle')
                elif(max**2 < mid**2 + mini**2):
                        print('Acute Triangle')
                elif(max**2 == mid**2 + mini**2):
                        print('Right Triangle')
        else:
                print('Not Triangle')
triangle()